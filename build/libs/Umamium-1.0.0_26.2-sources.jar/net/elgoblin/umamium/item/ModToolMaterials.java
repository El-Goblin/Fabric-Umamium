package net.elgoblin.umamium.item;

import net.elgoblin.umamium.tags.ModTags;
import net.minecraft.world.item.ToolMaterial;

public class ModToolMaterials {
    public static final ToolMaterial LEGENDARY = new ToolMaterial(
            ModTags.Blocks.INCORRECT_FOR_LEGENDARY_TOOL,
            3600000,
            30.0F,
            4.0F,
            30,
            ModTags.Items.LEGENDARY_REPAIR);
}
